// $(document).ready(function() {

//     $("#log").click(function() {
//         alert("Você logou com Suceesso!!!!!")
//         console.log("Você logou com Suceesso!!!!!")
//     })

//     $("#esquecer-senha").click(function() {
//         alert("Infelizmente não adicionamos nenhuma função para recuperar sua senha :(")
//         console.log("Infelizmente não adicionamos nenhuma função para recuperar sua senha :(")
//     })
// })
