$(document).ready(function() {

    $("[id^=comprar-click]").click(function() {
        alert("Você acaba de Comprar este Produto!!!")
        console.log("Você acaba de Comprar este Produto!!!")  
    })

})
